# IPTV Checker (conta única) — como gerar o APK

Este é um projeto Android nativo (Kotlin) completo. Ele **não** faz verificação em
lote de várias contas — você cadastra o servidor, usuário e senha da **sua própria
conta** e o app consulta o status dela (ativo/expirado, validade, conexões, e
contagem de canais/filmes/séries).

## Passo a passo (Android Studio — recomendado)

1. Baixe e instale o [Android Studio](https://developer.android.com/studio) (gratuito).
2. Abra o Android Studio → **Open** → selecione a pasta `IPTVCheckerSingle` (a raiz
   deste projeto, que contém `settings.gradle.kts`).
3. Aguarde o Android Studio baixar o Gradle e o SDK automaticamente (primeira vez
   demora alguns minutos, precisa de internet).
4. Para instalar direto no celular: conecte o aparelho via USB com "Depuração USB"
   ativada e clique em **Run ▶**.
5. Para gerar o arquivo `.apk` instalável:
   - Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   - O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.
   - Copie esse arquivo para o celular e instale (pode ser necessário permitir
     "instalar de fontes desconhecidas" nas configurações do Android).

## Passo a passo (linha de comando, alternativa)

Se preferir sem o Android Studio, com o Android SDK e JDK 17 instalados:

```bash
cd IPTVCheckerSingle
./gradlew assembleDebug
```

O APK sai em `app/build/outputs/apk/debug/app-debug.apk`.

## Estrutura do projeto

- `app/src/main/java/.../MainActivity.kt` — toda a lógica: formulário, chamada à
  API `player_api.php` (padrão Xtream Codes) e exibição do resultado.
- `app/src/main/res/layout/activity_main.xml` — tela única com campos de
  servidor/usuário/senha e o card de resultado.
- `AndroidManifest.xml` — permissão de internet e liberação de tráfego HTTP
  (muitos painéis IPTV ainda usam HTTP puro, sem HTTPS).

## Observações

- O app funciona com painéis no padrão Xtream Codes (`player_api.php`).
- Timeout de 10s por requisição.
- Não armazena nem envia dados para nenhum servidor além do que você digitar.
