package com.example.iptvchecker

import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var inputHost: TextInputEditText
    private lateinit var inputUsername: TextInputEditText
    private lateinit var inputPassword: TextInputEditText
    private lateinit var btnCheck: MaterialButton
    private lateinit var progressBar: android.widget.ProgressBar
    private lateinit var resultCard: CardView
    private lateinit var statusBadge: android.widget.TextView
    private lateinit var resultDetails: android.widget.TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputHost = findViewById(R.id.inputHost)
        inputUsername = findViewById(R.id.inputUsername)
        inputPassword = findViewById(R.id.inputPassword)
        btnCheck = findViewById(R.id.btnCheck)
        progressBar = findViewById(R.id.progressBar)
        resultCard = findViewById(R.id.resultCard)
        statusBadge = findViewById(R.id.statusBadge)
        resultDetails = findViewById(R.id.resultDetails)

        btnCheck.setOnClickListener { onCheckClicked() }
    }

    private fun onCheckClicked() {
        val host = inputHost.text?.toString()?.trim().orEmpty()
        val username = inputUsername.text?.toString()?.trim().orEmpty()
        val password = inputPassword.text?.toString()?.trim().orEmpty()

        if (host.isEmpty() || username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Preencha servidor, usuário e senha", Toast.LENGTH_SHORT).show()
            return
        }

        val baseUrl = if (host.startsWith("http://") || host.startsWith("https://")) {
            host.trimEnd('/')
        } else {
            "http://$host".trimEnd('/')
        }

        setLoading(true)
        resultCard.visibility = android.view.View.GONE

        lifecycleScope.launch {
            try {
                val apiUrl = "$baseUrl/player_api.php?username=$username&password=$password"
                val response = withContext(Dispatchers.IO) { fetchJson(apiUrl) }

                val userInfo = response.optJSONObject("user_info")
                val serverInfo = response.optJSONObject("server_info")

                if (userInfo == null) {
                    showError("Não foi possível ler os dados da conta. Verifique servidor/usuário/senha.")
                    return@launch
                }

                val status = userInfo.optString("status", "Unknown")

                // Contagens (opcionais, feitas em paralelo/sequência simples)
                val liveCount = withContext(Dispatchers.IO) {
                    fetchArraySize("$apiUrl&action=get_live_streams")
                }
                val vodCount = withContext(Dispatchers.IO) {
                    fetchArraySize("$apiUrl&action=get_vod_streams")
                }
                val seriesCount = withContext(Dispatchers.IO) {
                    fetchArraySize("$apiUrl&action=get_series")
                }

                showResult(status, userInfo, serverInfo, liveCount, vodCount, seriesCount)

            } catch (e: Exception) {
                showError("Erro ao conectar: ${e.message ?: "falha desconhecida"}")
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progressBar.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        btnCheck.isEnabled = !loading
        btnCheck.text = if (loading) "Verificando..." else "Verificar Conta"
    }

    private fun showError(message: String) {
        resultCard.visibility = android.view.View.VISIBLE
        statusBadge.text = "❌ ERRO"
        statusBadge.setTextColor(Color.parseColor("#EF4444"))
        resultDetails.text = message
    }

    private fun showResult(
        status: String,
        userInfo: JSONObject,
        serverInfo: JSONObject?,
        liveCount: Int,
        vodCount: Int,
        seriesCount: Int
    ) {
        resultCard.visibility = android.view.View.VISIBLE

        val isActive = status.equals("Active", ignoreCase = true)
        statusBadge.text = if (isActive) "✅ CONTA ATIVA" else "⚠️ STATUS: $status"
        statusBadge.setTextColor(
            Color.parseColor(if (isActive) "#22C55E" else "#F59E0B")
        )

        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
        val createdAt = userInfo.optString("created_at", "")
        val expDate = userInfo.optString("exp_date", "")

        val createdStr = formatEpoch(createdAt, sdf)
        val expStr = formatEpoch(expDate, sdf)

        val activeConns = userInfo.optString("active_cons", "0")
        val maxConns = userInfo.optString("max_connections", "N/A")
        val serverUrl = serverInfo?.optString("url") ?: "N/A"
        val port = serverInfo?.optString("port") ?: "N/A"

        resultDetails.text = buildString {
            appendLine("Criado em: $createdStr")
            appendLine("Expira em: $expStr")
            appendLine("Conexões: $activeConns / $maxConns")
            appendLine("Servidor: $serverUrl")
            appendLine("Porta: $port")
            appendLine()
            appendLine("Canais ao vivo: $liveCount")
            appendLine("Filmes (VOD): $vodCount")
            appendLine("Séries: $seriesCount")
        }
    }

    private fun formatEpoch(value: String, sdf: SimpleDateFormat): String {
        val epoch = value.toLongOrNull() ?: return "N/A"
        if (epoch <= 0) return "N/A"
        return sdf.format(Date(epoch * 1000))
    }

    /** Faz uma requisição GET e retorna o corpo como JSONObject. */
    private fun fetchJson(urlString: String): JSONObject {
        val connection = openConnection(urlString)
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        connection.disconnect()
        return JSONObject(body)
    }

    /** Faz uma requisição GET e retorna o tamanho do array JSON retornado (0 se falhar). */
    private fun fetchArraySize(urlString: String): Int {
        return try {
            val connection = openConnection(urlString)
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val arr = org.json.JSONArray(body)
            arr.length()
        } catch (e: Exception) {
            0
        }
    }

    private fun openConnection(urlString: String): HttpURLConnection {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = TimeUnit.SECONDS.toMillis(10).toInt()
        connection.readTimeout = TimeUnit.SECONDS.toMillis(10).toInt()
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "IPTVChecker/1.0")
        connection.connect()
        return connection
    }
}
